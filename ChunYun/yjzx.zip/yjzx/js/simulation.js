var moniData = [
  {
    name:'广州南站',
    pos:{
      lat: 22.988766,
      lng: 113.269391
    },
    zoom: 18
  },
  {
    name:'清远市城北汽车客运站',
    pos:{
      lat: 23.723292,
      lng: 113.003648
    },
    zoom: 18

  },
  {
    name:'惠州站',
    pos:{
      lat: 23.151307,
      lng: 114.416115
    },
    zoom: 18

  }
]
